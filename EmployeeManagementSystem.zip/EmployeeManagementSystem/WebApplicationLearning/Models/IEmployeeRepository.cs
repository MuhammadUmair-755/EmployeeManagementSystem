﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationLearning.Models
{
    public interface IEmployeeRepository
    {
        public IEnumerable<Employee> GetAllEmployees();
        public void Create(Employee employee);
        public Employee Details(int id);

        public Employee Edit(int id);

        public Employee Edit(int id, Employee employee);
        public Employee Delete(int id);
        public void Delete( Employee employee);
    }
}
