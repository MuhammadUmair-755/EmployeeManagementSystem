﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace WebApplicationLearning.Models
{
    public class SQL_EmpRepository : IEmployeeRepository 
    {
        private readonly EmployeeDBContext context;

        public SQL_EmpRepository(EmployeeDBContext _context)
        {
            context = _context;
        }
        public IEnumerable<Employee> GetAllEmployees()  
        {
            return context.Employees.ToList();
        }

        public Employee Edit(int id) //get edit
        {
            var employee=context.Employees.Find(id);
            return employee;
        }
        void IEmployeeRepository.Create(Employee employee)  //post create
        {
            
            context.Employees.Add(employee);
            context.SaveChanges();
                 
            }

        Employee IEmployeeRepository.Details(int id){  // get details
            var employee=context.Employees.FirstOrDefault(x => x.Id == id);
            
            return employee;
        }
        Employee IEmployeeRepository.Edit(int id , Employee employee) //post edit
        {
            context.Employees.Update(employee);
            context.SaveChanges();
            return employee;
        }

        Employee IEmployeeRepository.Delete(int id)  // get del
        {
            var employee= context.Employees.FirstOrDefault(x=>x.Id == id);
            return employee;
        }
        void IEmployeeRepository.Delete( Employee employee)  //post del
        {
            var existingEmployee = context.Employees.Find(employee.Id); 
            if (existingEmployee != null)
            {
                context.Employees.Remove(existingEmployee);
                context.SaveChanges();
            }
        } 
    }
    }

