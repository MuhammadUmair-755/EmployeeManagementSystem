﻿using Microsoft.EntityFrameworkCore;

namespace WebApplicationLearning.Models
{
    public static class ModelBuilderExtenstions
    {
        public static void seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>().HasData(
               new Employee
               {
                   Id = 1,
                   Name = "Mary",
                   Department = "HR",
                   Email = "mary@gmail.com"
               }

               );
        }

    }
}
