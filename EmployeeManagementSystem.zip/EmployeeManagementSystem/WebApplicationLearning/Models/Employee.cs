﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplicationLearning.Models
{
    public class Employee
    {
        [Key]
        public int Id{ get; set; }
        [NotMapped]
        public string EncryptedID { get; set; }

        [Required]
        public string Name { get; set; }
        [Required]
        [RegularExpression("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",ErrorMessage="Invalid Format")]
        public string Email{ get; set; }
        [Required]
        public string Department{ get; set; }
    }
}
