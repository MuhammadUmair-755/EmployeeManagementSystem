using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages;
using NLog;
using NLog.Extensions.Logging;
using NLog.Web;
using WebApplicationLearning.Models;
using WebApplicationLearning.Security;

namespace WebApplicationLearning
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();
            var provider = builder.Services.BuildServiceProvider();
            var config = provider.GetRequiredService<IConfiguration>();
            builder.Services.AddDbContext<EmployeeDBContext>(item => item.UseSqlServer(config.GetConnectionString("dbcs")));
            builder.Services.AddScoped<IEmployeeRepository, SQL_EmpRepository>();
            builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
            {
                options.Lockout.MaxFailedAccessAttempts = 3;
                options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);

            })
                .AddEntityFrameworkStores<EmployeeDBContext>()
                .AddDefaultTokenProviders();
            builder.Services.Configure<IdentityOptions>(options =>  // changing default Password valiations
            {
                options.Password.RequiredLength = 10;
                options.Password.RequiredUniqueChars = 3;
                options.SignIn.RequireConfirmedEmail = true;
            });
            
            builder.Services.AddSingleton<DataProtectionPurposeStrings>();

            builder.Services.AddDataProtection();
            // Configure Logging
           
            builder.Host.UseNLog();
            
            builder.Services.AddAuthorization(options =>
            {
                options.AddPolicy("DeleteRolePolicy", policy => policy.RequireAssertion(context =>
                 context.User.IsInRole("Admin") && context.User.HasClaim(c => c.Type == "Delete Role" && c.Value == "true") ||
                 context.User.IsInRole("Super Admin")));

                //options.AddPolicy("EditRolePolicy", policy => policy.RequireAssertion(context=>
                //context.User.IsInRole("Admin")&& context.User.HasClaim(c=>c.Type=="Edit Role" && c.Value=="true") || 
                //context.User.IsInRole("Super Admin")));
                options.AddPolicy("EditRolePolicy", policy => policy.AddRequirements(new ManageAdminRolesAndClaimsRequirements()));

                options.AddPolicy("CreateRolePolicy", policy => policy.RequireAssertion(context =>
                context.User.IsInRole("Admin") && context.User.HasClaim(c => c.Type == "Create Role" && c.Value == "true") ||
                context.User.IsInRole("Super Admin")));                // Role Policy
                options.AddPolicy("AdminRolePolicy", policy => policy.RequireAssertion(context =>
                context.User.IsInRole("Admin") ||
                context.User.IsInRole("Super Admin")));// we can mulitple roles in this policy
            });
            builder.Services.AddSingleton<IAuthorizationHandler, CanEditOnlyOtherAdminRolesAndClaimsHandler>();
            builder.Services.AddSingleton<IAuthorizationHandler, SuperAdminHandler>();
            builder.Services.AddHttpContextAccessor();
           
            builder.Services.AddAuthentication().AddGoogle(options =>
            {
                options.ClientId = "334070412120-i5jsfmer6jkfi9d1t9ov1gfj9pk4o106.apps.googleusercontent.com";
                options.ClientSecret = "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";
                options.Events = new Microsoft.AspNetCore.Authentication.OAuth.OAuthEvents
                {
                    OnRemoteFailure = context =>
                    {
                        // redirect user back to login page if they cancel or any error occurs
                        context.Response.Redirect("/Account/Login?error=ExternalLoginFailed");
                        context.HandleResponse(); // mark as handled so it doesn�t throw
                        return Task.CompletedTask;
                    }
                };
            })
             .AddFacebook(options =>
             {
                 options.AppId = "1122834686480713";
                 options.AppSecret = "c2cd84b681c3a8314a191975473ad4d0";
             });
             
            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }
            else
            {
                app.UseStatusCodePagesWithReExecute("/Error/{0}");
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.Use(async (context, next) =>
            {
                try
                {
                    await next();
                }
                catch (Microsoft.AspNetCore.Authentication.AuthenticationFailureException)
                {
                    context.Response.Redirect("/Account/Login?error=ExternalLoginFailed");
                }
               
            });
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();


            //app.MapControllers();
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");
            app.Run();
        }
        
    
    }
}
