﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApplicationLearning.Migrations
{
    /// <inheritdoc />
    public partial class AlterEmployeeSeed : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Department", "Email", "Name" },
                values: new object[] { "HR", "mary@gmail.com", "Mary" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Department", "Email", "Name" },
                values: new object[] { "IT", "mark@gmail.com", "Mark" });
        }
    }
}
