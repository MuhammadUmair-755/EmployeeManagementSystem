using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplicationLearning.Models;
using WebApplicationLearning.Security;

namespace WebApplicationLearning.Controllers
{

    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IEmployeeRepository emp_Repository;
        private readonly IDataProtector dataProtector;
        private readonly DataProtectionPurposeStrings dataProtectionPurposeStrings;

        public IDataProtectionProvider DataProtectionProvider { get; }

        public HomeController(ILogger<HomeController> logger, IEmployeeRepository _emp_repository,
            IDataProtectionProvider dataProtectionProvider,
            DataProtectionPurposeStrings dataProtectionPurposeStrings)
        {
            _logger = logger;
            emp_Repository = _emp_repository;
            DataProtectionProvider = dataProtectionProvider;
            dataProtector = dataProtectionProvider.CreateProtector(dataProtectionPurposeStrings.EmployeeIdRouteValue);
        }
        [AllowAnonymous]
        public IActionResult Index()
        {
            var employee = emp_Repository.GetAllEmployees().Select(e =>
            {
                e.EncryptedID =dataProtector.Protect( e.Id.ToString());
                return e;
            });
            return View(employee);
        }
        [Authorize]
        public IActionResult Delete(int id)
        {
            var employee = emp_Repository.Delete(id);
            return View(employee);
        }
        [HttpPost,ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id )
        {
            var employee = new Employee { Id = id };
            if (ModelState.IsValid)
            {
                emp_Repository.Delete(employee);
                return RedirectToAction("Index");
            }
            return View(employee);
        }
        public IActionResult Create()
        {            
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employee employee)
        {
            if (ModelState.IsValid)
            {
                emp_Repository.Create(employee);
                return RedirectToAction("Index");
            }
            return View(employee);
        }
        public IActionResult Edit(int id)
        {
            var employee = emp_Repository.Edit(id);
            return View(employee);
        }
        [HttpPost]
        public IActionResult Edit(int id,Employee employee)
        {
            if (ModelState.IsValid)
            {
                emp_Repository.Edit(id, employee);
                return RedirectToAction("Index");
            }

            return View(employee);
        }
        [AllowAnonymous]
        public IActionResult Details(string id)
        {
            int decryptedId=Convert.ToInt32(dataProtector.Unprotect(id));
            var employee=emp_Repository.Details(decryptedId);
            if (employee == null)
            {
                _logger.LogWarning("Exception that Employee Does not exist");
                return View("EmployeeNotFound",decryptedId);
            }
            return View(employee);
        }
        
     
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
