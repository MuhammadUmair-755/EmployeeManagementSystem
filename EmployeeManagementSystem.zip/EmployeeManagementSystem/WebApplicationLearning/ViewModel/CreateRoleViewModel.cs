﻿using System.ComponentModel.DataAnnotations;

namespace WebApplicationLearning.ViewModel
{
    public class CreateRoleViewModel
    {
        [Required]
        public string RoleName { get; set; }
    }
}
