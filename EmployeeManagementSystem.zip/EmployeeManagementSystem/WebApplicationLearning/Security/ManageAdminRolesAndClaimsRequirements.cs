﻿using Microsoft.AspNetCore.Authorization;

namespace WebApplicationLearning.Security
{
    public class ManageAdminRolesAndClaimsRequirements : IAuthorizationRequirement
    {
         
    }
}
