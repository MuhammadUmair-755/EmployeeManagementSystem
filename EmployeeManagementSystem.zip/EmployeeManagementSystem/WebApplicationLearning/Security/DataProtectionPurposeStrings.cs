﻿namespace WebApplicationLearning.Security
{
    public class DataProtectionPurposeStrings
    {
        public readonly string EmployeeIdRouteValue = "EmployeeIdRouteValue";

    }
}
