﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;

namespace WebApplicationLearning.Security
{
    public class CanEditOnlyOtherAdminRolesAndClaimsHandler : AuthorizationHandler<ManageAdminRolesAndClaimsRequirements>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public CanEditOnlyOtherAdminRolesAndClaimsHandler(IHttpContextAccessor httpContextAccessor)// DI for accessing route data
        {
            _httpContextAccessor = httpContextAccessor;
        }
        protected override Task HandleRequirementAsync
            (AuthorizationHandlerContext context, ManageAdminRolesAndClaimsRequirements requirement)
        {
            
            var httpContext = _httpContextAccessor.HttpContext;

            if (httpContext == null)
                return Task.CompletedTask;
            string loggedInAdminId = context.User.Claims.FirstOrDefault(c=>c.Type==ClaimTypes.NameIdentifier).Value;
             string adminIdBeingEdited = httpContext.Request.Query["userId"];
             if(context.User.IsInRole("Admin") && context.User.HasClaim(c => c.Type == "Edit Role" && c.Value == "true") && adminIdBeingEdited==null)
            {
                context.Succeed(requirement);
            }
            else if (adminIdBeingEdited != null && context.User.IsInRole("Admin") && context.User.HasClaim(c => c.Type == "Edit Role" && c.Value == "true")
                && adminIdBeingEdited.ToLower() != loggedInAdminId.ToLower())
            {
                context.Succeed(requirement);
            }
                return Task.CompletedTask;




        }
    }
}
